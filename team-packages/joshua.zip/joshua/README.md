# Joshua — frontend/responsive-ui

## Your Branch
`frontend/responsive-ui`

## Your Files
- `script.js` — main dashboard JS logic (simulation loop, Plotly rendering, logs)
- `style.css` — all UI styles
- `index.html` — main dashboard HTML

## Your Task
Make the UI fully responsive for mobile and tablet screens.
The current layout breaks on smaller screens.

## Specific Things To Fix
1. Sidebar should collapse on mobile (hamburger menu or bottom bar)
2. Plotly charts should resize properly on small screens
3. Font sizes should scale down on mobile
4. The viz-grid should stack vertically on screens below 768px

## How To Push
```bash
git checkout frontend/responsive-ui
# make your changes to the files
git add .
git commit -m "feat: responsive layout for mobile and tablet"
git push origin frontend/responsive-ui
```

## Files Location In The Repo
- `PHone/PHone/static/script.js`
- `PHone/PHone/static/style.css`
- `PHone/PHone/templates/index.html`
